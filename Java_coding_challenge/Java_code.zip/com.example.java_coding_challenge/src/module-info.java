/**
 * 
 */
/**
 * 
 */
module com.example.java_coding_challenge {
	requires java.sql;
}