package com.example.java_coding_challenge.util;
import java.io.FileInputStream;

import java.io.IOException;
import java.util.Properties;
public class DBPropertyUtil {
	public static String[] getPropertyString(String filename) {
		Properties props = new Properties();

		try (FileInputStream fis = new FileInputStream(filename)) {
			props.load(fis);
			String url = props.getProperty("InsuranceDB.url");
			String username = props.getProperty("InsuranceDB.username");
			String password = props.getProperty("InsuranceDB.password");

			return new String[] { url, username, password };
		} catch (IOException e) {
			System.err.println("Failed to load DB properties file: " + filename);
			e.printStackTrace();
			return null;
		}
	}
}
