package com.example.java_coding_challenge.util;

import java.sql.*;

public class DBConnUtil {
	public static Connection conn;

	public static Connection getConn(String filename) {
		System.out.println("Getting DB connection using file: " + filename);

		if (conn == null) {
			try {
				String[] connStr = DBPropertyUtil.getPropertyString(filename);
				System.out.println(connStr[0]);
				conn = DriverManager.getConnection(connStr[0], connStr[1], connStr[2]);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return conn;
	}
}
