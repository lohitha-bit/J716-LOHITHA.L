package com.example.java_coding_challenge.main;

import java.util.*;

import com.example.java_coding_challenge.dao.*;
import com.example.java_coding_challenge.entity.*;
import com.example.java_coding_challenge.exception.*;

public class MainModule {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		IPolicyService service = new InsuranceServiceImpl();
		int choice;

		do {
			System.out.println("\n--- Insurance Management System ---");
			System.out.println("1. Create Policy");
			System.out.println("2. View Policy by ID");
			System.out.println("3. View All Policies");
			System.out.println("4. Update Policy");
			System.out.println("5. Delete Policy");
			System.out.println("6. Exit");
			System.out.print("Enter your choice: ");
			choice = scanner.nextInt();

			try {
				switch (choice) {
				case 1:
					System.out.print("Enter Policy ID: ");
					int policyId = scanner.nextInt();
					scanner.nextLine();

					System.out.print("Enter Policy Name: ");
					String name = scanner.nextLine();

					System.out.print("Enter Policy Type: ");
					String type = scanner.nextLine();

					System.out.print("Enter Policy Amount: ");
					double amount = scanner.nextDouble();
					scanner.nextLine();

					Policy newPolicy = new Policy(policyId, name, type, amount);
					boolean created = service.createPolicy(newPolicy);
					System.out.println(created ? "Policy created successfully." : "Failed to create policy.");
					break;

				case 2:
					System.out.print("Enter Policy ID: ");
					int id = scanner.nextInt();
					Policy found = service.getPolicy(id);
					System.out.println(found);
					break;

				case 3:
					System.out.println("All Policies:");
					Collection<Policy> policies = service.getAllPolicies();
					for (Policy policy : policies) {
						System.out.println(policy);
					}
					break;

				case 4:
					System.out.print("Enter Policy ID to Update: ");
					int updateId = scanner.nextInt();
					scanner.nextLine(); // consume newline

					System.out.print("Enter Updated Policy Name: ");
					String updatedName = scanner.nextLine();

					System.out.print("Enter Updated Policy Type: ");
					String updatedType = scanner.nextLine();

					System.out.print("Enter Updated Policy Amount: ");
					double updatedAmount = scanner.nextDouble();
					scanner.nextLine();

					Policy updatedPolicy = new Policy(updateId, updatedName, updatedType, updatedAmount);
					boolean updated = service.updatePolicy(updatedPolicy);
					System.out.println(updated ? "Policy updated successfully." : "Failed to update policy.");
					break;

				case 5:
					System.out.print("Enter Policy ID to Delete: ");
					int deleteId = scanner.nextInt();
					boolean deleted = service.deletePolicy(deleteId);
					System.out.println(deleted ? "Policy Deleted" : "Policy Not Found");
					break;

				case 6:
					System.out.println("Exiting Application...");
					break;

				default:
					System.out.println("Invalid Choice");
				}
			} catch (PolicyNotFoundException e) {
				System.err.println("Error: " + e.getMessage());
			} catch (Exception e) {
				System.err.println("Unexpected Error: " + e.getMessage());
				e.printStackTrace();
			}

		} while (choice != 6);

		scanner.close();
	}
}
