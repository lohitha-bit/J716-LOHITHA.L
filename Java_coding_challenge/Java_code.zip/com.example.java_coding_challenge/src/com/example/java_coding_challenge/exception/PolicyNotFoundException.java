package com.example.java_coding_challenge.exception;

public class PolicyNotFoundException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PolicyNotFoundException(String message) {
        super(message);
    }
}
