package com.example.java_coding_challenge.dao;

import java.sql.*;
import java.util.ArrayList;

import java.util.List;

import com.example.java_coding_challenge.entity.*;
import com.example.java_coding_challenge.exception.PolicyNotFoundException;
import com.example.java_coding_challenge.util.*;

public class InsuranceServiceImpl implements IPolicyService{
	private static Connection conn = DBConnUtil.getConn("resources/db.properties");

	@Override
	public boolean createPolicy(Policy policy) {
	    String query = "INSERT INTO policies (policyId, policyName, policyType, amount) VALUES (?, ?, ?, ?)";

	    try (PreparedStatement ps = conn.prepareStatement(query)) {
	        ps.setInt(1, policy.getPolicyId());
	        ps.setString(2, policy.getPolicyName());
	        ps.setString(3, policy.getPolicyType());
	        ps.setDouble(4, policy.getAmount());

	        int rows = ps.executeUpdate();
	        return rows > 0;

	    } catch (SQLIntegrityConstraintViolationException e) {
	        System.err.println("Policy with ID " + policy.getPolicyId() + " already exists.");
	    } catch (SQLException e) {
	        System.err.println("SQL Error while creating policy: " + e.getMessage());
	    } catch (Exception e) {
	        System.err.println("Unexpected Error while creating policy: " + e.getMessage());
	    }

	    return false;
	}


    @Override
    public Policy getPolicy(int policyId) throws PolicyNotFoundException {
        String sql = "SELECT * FROM policies WHERE policyId = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, policyId);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Policy(
                    rs.getInt("policyId"),
                    rs.getString("policyName"),
                    rs.getString("policyType"),
                    rs.getDouble("Amount")
                );
            } else {
                throw new PolicyNotFoundException("Policy with ID " + policyId + " not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new PolicyNotFoundException("Database error occurred while fetching policy.");
        }
    }

    @Override
    public List<Policy> getAllPolicies() {
        List<Policy> policies = new ArrayList<>();
        String sql = "SELECT * FROM policies";

        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                policies.add(new Policy(
                    rs.getInt("policyId"),
                    rs.getString("policyName"),
                    rs.getString("policyType"),
                    rs.getDouble("amount")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return policies;
    }

    @Override
    public boolean updatePolicy(Policy policy) throws PolicyNotFoundException {
        
        getPolicy(policy.getPolicyId());

        String sql = "UPDATE policies SET policyName = ?, policyType = ?, amount = ? WHERE policyId = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, policy.getPolicyName());
            ps.setString(2, policy.getPolicyType());
            ps.setDouble(3, policy.getAmount());
            ps.setInt(4, policy.getPolicyId());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deletePolicy(int policyId) throws PolicyNotFoundException {
        
        getPolicy(policyId);

        String sql = "DELETE FROM policies WHERE policyId = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, policyId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
