package com.example.java_coding_challenge.dao;
import com.example.java_coding_challenge.exception.*;
import java.util.Collection;

import com.example.java_coding_challenge.entity.*;

public interface IPolicyService {
	boolean createPolicy(Policy policy);

    Policy getPolicy(int policyId)throws PolicyNotFoundException;

    Collection<Policy> getAllPolicies();

    boolean updatePolicy(Policy policy)throws PolicyNotFoundException;

    boolean deletePolicy(int policyId)throws PolicyNotFoundException;
}
