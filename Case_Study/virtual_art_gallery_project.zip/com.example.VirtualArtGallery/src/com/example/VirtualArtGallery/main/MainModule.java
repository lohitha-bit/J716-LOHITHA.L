package com.example.VirtualArtGallery.main;


import java.util.Date;

import java.text.SimpleDateFormat;
import java.util.*;

import com.example.VirtualArtGallery.dao.*;
import com.example.VirtualArtGallery.entity.*;
import com.example.VirtualArtGallery.exception.*;


public class MainModule {

	public static void main(String[] args) throws ArtWorkNotFoundException {

		Scanner sc = new Scanner(System.in);
		VirtualArtGalleryServiceImpl service = new VirtualArtGalleryServiceImpl();
		

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		while (true) {
			System.out.println("\n--- Virtual Art Gallery Main Menu ---");
			System.out.println("1. Artwork Management");
			System.out.println("2. Personal Gallery Management");
			System.out.println("3. Gallery Management");
			System.out.println("4. Exit");
			System.out.print("Enter your choice: ");
			int mainChoice = sc.nextInt();
			sc.nextLine();

			switch (mainChoice) {
				case 1:
					artworkMenu(sc, service, sdf);
					break;
				case 2:
					personalGalleryMenu(sc, service);
					break;
				case 3:
					galleryMenu(sc, service);
					break;
				case 4:
					System.out.println("Thank you for visiting the Virtual Art Gallery!");
					sc.close();
					System.exit(0);
				default:
					System.out.println("Invalid choice, try again.");
			}
		}
	}

	
	private static void artworkMenu(Scanner sc, VirtualArtGalleryServiceImpl service, SimpleDateFormat sdf) {
		while (true) {
			System.out.println("\n--- Artwork Management ---");
			System.out.println("1. Add Artwork");
			System.out.println("2. Update Artwork");
			System.out.println("3. Delete Artwork");
			System.out.println("4. Search Artwork by ID");
			System.out.println("5. Search Artwork by Title or Description");
			System.out.println("6. Back to Main Menu");
			System.out.print("Enter your choice: ");
			int choice = sc.nextInt();
			sc.nextLine();

			try {
				switch (choice) {
					case 1:
						System.out.print("Enter Artwork ID: ");
						int artworkId = sc.nextInt();
						sc.nextLine();

						System.out.print("Enter Title: ");
						String title = sc.nextLine();

						System.out.print("Enter Description: ");
						String description = sc.nextLine();

						System.out.print("Enter Creation Date (yyyy-MM-dd): ");
						String dateStr = sc.nextLine();
						Date creationDate = null;
						try {
							creationDate = sdf.parse(dateStr);
						} catch (Exception e) {
							System.out.println("Invalid date format. Please use yyyy-MM-dd.");
							break;
						}

						System.out.print("Enter Medium: ");
						String medium = sc.nextLine();

						System.out.print("Enter Image URL: ");
						String imageUrl = sc.nextLine();

						System.out.print("Enter Artist ID: ");
						int artistId = sc.nextInt();
						sc.nextLine();

						Artwork newArt = new Artwork(artworkId, title, description,
								new java.sql.Date(creationDate.getTime()), medium, imageUrl, artistId);
						boolean added = service.addArtwork(newArt);
						System.out.println(added ? "Artwork added successfully." : "Failed to add artwork.");
						break;

					case 2:
						System.out.print("Enter Artwork ID to Update: ");
						int artworkId1 = sc.nextInt();
						sc.nextLine();

						System.out.print("Enter Title: ");
						String title1 = sc.nextLine();

						System.out.print("Enter Description: ");
						String description1 = sc.nextLine();

						System.out.print("Enter Creation Date (yyyy-MM-dd): ");
						String dateStr1 = sc.nextLine();
						Date creationDate1 = null;
						try {
							creationDate1 = sdf.parse(dateStr1);
						} catch (Exception e) {
							System.out.println("Invalid date format. Please use yyyy-MM-dd.");
							break;
						}

						System.out.print("Enter Medium: ");
						String medium1 = sc.nextLine();

						System.out.print("Enter Image URL: ");
						String imageUrl1 = sc.nextLine();

						System.out.print("Enter Artist ID: ");
						int artistId1 = sc.nextInt();
						sc.nextLine();

						Artwork updateArt = new Artwork(artworkId1, title1, description1,
								new java.sql.Date(creationDate1.getTime()), medium1, imageUrl1, artistId1);
						boolean updated = service.updateArtwork(updateArt);
						System.out.println(updated ? "Artwork updated successfully." : "Failed to update artwork.");
						break;

					case 3:
						System.out.print("Enter Artwork ID to remove: ");
						int removeId = sc.nextInt();
						sc.nextLine();

						boolean art = service.removeArtwork(removeId);
						System.out.println(art ? "Artwork removed successfully." : "Failed to remove artwork.");
						break;

					case 4:
						System.out.print("Enter Artwork ID to search: ");
						int searchId = sc.nextInt();
						sc.nextLine();

						try {
							Artwork art1 = service.getArtworkById(searchId);
							System.out.println("\nArtwork Details:");
							System.out.println("ID: " + art1.getArtworkId());
							System.out.println("Title: " + art1.getTitle());
							System.out.println("Description: " + art1.getDescription());
							System.out.println("Created on: " + art1.getCreationDate());
							System.out.println("Medium: " + art1.getMedium());
							System.out.println("Image URL: " + art1.getImageUrl());
							System.out.println("Artist ID: " + art1.getArtistId());
						} catch (ArtWorkNotFoundException e) {
							System.out.println("Error: " + e.getMessage());
						}
						break;

					case 5:
						System.out.print("Enter Title or Description to search Artwork : ");
						String searchStr = sc.nextLine();

						List<Artwork> search = service.searchArtworks(searchStr);

						if (search.isEmpty()) {
							System.out.println("No artworks found matching the search criteria.");
						} else {
							for (Artwork art1 : search) {
								System.out.println("\nArtwork Details:");
								System.out.println("ID: " + art1.getArtworkId());
								System.out.println("Title: " + art1.getTitle());
								System.out.println("Description: " + art1.getDescription());
								System.out.println("Created on: " + art1.getCreationDate());
								System.out.println("Medium: " + art1.getMedium());
								System.out.println("Image URL: " + art1.getImageUrl());
								System.out.println("Artist ID: " + art1.getArtistId());
							}
						}
						break;

					case 6:
						return;
					default:
						System.out.println("Invalid option.");
				}
			} catch (Exception e) {
				System.out.println("Error: " + e.getMessage());
			}
		}
	}

	
	private static void personalGalleryMenu(Scanner sc, VirtualArtGalleryServiceImpl service) {
		while (true) {
			System.out.println("\n--- Personal Gallery Management ---");
			System.out.println("1. Add Artwork to Favorites");
			System.out.println("2. Remove Artwork from Favorites");
			System.out.println("3. View Favorite Artworks");
			System.out.println("4. Back to Main Menu");
			System.out.print("Enter your choice: ");
			int choice = sc.nextInt();
			sc.nextLine();

			try {
				switch (choice) {
					case 1:
						System.out.print("Enter User ID: ");
						int favUserId = sc.nextInt();
						System.out.print("Enter Artwork ID to add to favorites: ");
						int favArtId = sc.nextInt();

						if (service.addArtworkToFavorite(favUserId, favArtId)) {
							System.out.println("Artwork added to favorites.");
						} else {
							System.out.println("Failed to add to favorites.");
						}
						break;

					case 2:
						System.out.print("Enter User ID: ");
						int remUserId = sc.nextInt();
						System.out.print("Enter Artwork ID to remove from favorites: ");
						int remArtId = sc.nextInt();

						if (service.removeArtworkFromFavorite(remUserId, remArtId)) {
							System.out.println("Artwork removed from favorites.");
						} else {
							System.out.println("Artwork not found in favorites.");
						}
						break;

					case 3:
						System.out.print("Enter User ID to view personal gallery: ");
						int userIdForGallery = sc.nextInt();
						sc.nextLine();

						System.out.print("Enter your password: ");
						String password = sc.nextLine();

						if (service.validateUser(userIdForGallery, password)) {
							List<Artwork> favArtworks = service.getUserFavoriteArtworks(userIdForGallery);
							if (favArtworks.isEmpty()) {
								System.out.println("You have no favorite artworks.");
							} else {
								System.out.println("\n--- Favorite Artworks ---");
								for (Artwork a : favArtworks) {
									System.out.println("ID: " + a.getArtworkId() + ", Title: " + a.getTitle() + ", Medium: "
											+ a.getMedium());
								}
							}
						} else {
							System.out.println("Invalid User ID or Password. Access denied.");
						}
						break;

					case 4:
						return;
					default:
						System.out.println("Invalid option.");
				}
			} catch (Exception e) {
				System.out.println("Error: " + e.getMessage());
			}
		}
	}

	
	private static void galleryMenu(Scanner sc, VirtualArtGalleryServiceImpl service) {
		while (true) {
			System.out.println("\n--- Gallery Management ---");
			System.out.println("1. Add Gallery");
			System.out.println("2. Update Gallery");
			System.out.println("3. Delete Gallery");
			System.out.println("4. Search Gallery by ID");
			System.out.println("5. View All Galleries");
			System.out.println("6. Back to Main Menu");
			System.out.print("Enter your choice: ");
			int choice = sc.nextInt();
			sc.nextLine();

			try {
				switch (choice) {
					case 1:
						System.out.print("Enter Gallery ID: ");
						int gid = sc.nextInt();
						sc.nextLine();
						System.out.print("Name: ");
						String gname = sc.nextLine();
						System.out.print("Description: ");
						String gdesc = sc.nextLine();
						System.out.print("Location: ");
						String glocation = sc.nextLine();
						System.out.print("Curator ID: ");
						int curator = sc.nextInt();
						sc.nextLine();
						System.out.print("Opening Hours: ");
						String hours = sc.nextLine();

						Gallery gal = new Gallery(gid, gname, gdesc, glocation, curator, hours);
						boolean added = service.addGallery(gal);
						System.out.println(added ? "Gallery added." : "Failed to add.");
						break;

					case 2:
						System.out.println("Enter Gallery ID to update:");
						int updateId = sc.nextInt();
						sc.nextLine();
						System.out.print("New Name: ");
						String newName = sc.nextLine();
						System.out.print("New Description: ");
						String newDesc = sc.nextLine();
						System.out.print("New Location: ");
						String newLocation = sc.nextLine();
						System.out.print("New Curator ID: ");
						int newCurator = sc.nextInt();
						sc.nextLine();
						System.out.print("New Opening Hours: ");
						String newHours = sc.nextLine();

						Gallery updatedGallery = new Gallery(updateId, newName, newDesc, newLocation, newCurator, newHours);
						boolean updated = service.updateGallery(updatedGallery);
						System.out.println(updated ? "Gallery updated successfully." : "Gallery update failed.");
						break;

					case 3:
						System.out.print("Enter Gallery ID to delete: ");
						int deleteId = sc.nextInt();
						boolean deleted = service.deleteGallery(deleteId);
						System.out.println(deleted ? "Gallery deleted successfully." : "Gallery not found or failed to delete.");
						break;

					case 4:
						System.out.print("Enter Gallery ID to search: ");
						int searchId = sc.nextInt();
						Gallery gallery = service.getGalleryById(searchId);
						System.out.println("\n--- Gallery Details ---");
						System.out.println("ID: " + gallery.getGalleryID());
						System.out.println("Name: " + gallery.getName());
						System.out.println("Description: " + gallery.getDescription());
						System.out.println("Location: " + gallery.getLocation());
						System.out.println("Curator ID: " + gallery.getCuratorID());
						System.out.println("Opening Hours: " + gallery.getOpeningHours());
						break;

					case 5:
						System.out.println("\n--- All Galleries ---");
						for (Gallery g : service.getAllGalleries()) {
							System.out.println("ID: " + g.getGalleryID() + ", Name: " + g.getName() + ", Location: " + g.getLocation());
						}
						break;

					case 6:
						return;
					default:
						System.out.println("Invalid option.");
				}
			} catch (Exception e) {
				System.out.println("Error: " + e.getMessage());
			}
		}
	}
}
