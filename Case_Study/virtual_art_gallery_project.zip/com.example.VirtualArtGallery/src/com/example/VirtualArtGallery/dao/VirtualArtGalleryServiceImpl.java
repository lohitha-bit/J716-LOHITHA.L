package com.example.VirtualArtGallery.dao;

import java.sql.*;

import java.util.*;

import com.example.VirtualArtGallery.entity.*;
import com.example.VirtualArtGallery.exception.*;
import com.example.VirtualArtGallery.util.*;

public class VirtualArtGalleryServiceImpl implements IVirtualArtGallery {

	private static Connection conn;

	public VirtualArtGalleryServiceImpl() {
		conn = DBConnUtil.getConn("resources/db.properties");
	}

	@Override
	public boolean addArtwork(Artwork artwork) {
		String query = "INSERT INTO Artwork (Title, Description, CreationDate, Medium, ImageURL, ArtistID) VALUES (?, ?, ?, ?, ?, ?)";
		try (PreparedStatement stmt = conn.prepareStatement(query)) {
			stmt.setString(1, artwork.getTitle());
			stmt.setString(2, artwork.getDescription());
			stmt.setDate(3, new java.sql.Date(artwork.getCreationDate().getTime()));
			stmt.setString(4, artwork.getMedium());
			stmt.setString(5, artwork.getImageUrl());
			stmt.setInt(6, artwork.getArtistId());
			int rows = stmt.executeUpdate();
			System.out.println(rows);
			return rows > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean updateArtwork(Artwork artwork) {
		String query = "UPDATE Artwork SET Title=?, Description=?, CreationDate=?, Medium=?, ImageURL=?, ArtistID=? WHERE ArtworkID=?";
		try (PreparedStatement stmt = conn.prepareStatement(query)) {
			stmt.setString(1, artwork.getTitle());
			stmt.setString(2, artwork.getDescription());
			stmt.setDate(3, new java.sql.Date(artwork.getCreationDate().getTime()));
			stmt.setString(4, artwork.getMedium());
			stmt.setString(5, artwork.getImageUrl());
			stmt.setInt(6, artwork.getArtistId());
			System.out.println(artwork.getArtworkId());
			stmt.setInt(7, artwork.getArtworkId());
			int rows = stmt.executeUpdate();
			System.out.println(rows);
			return rows > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean removeArtwork(int artworkId) {
		String query = "DELETE FROM Artwork WHERE ArtworkID = ?";
		try (PreparedStatement stmt = conn.prepareStatement(query)) {
			stmt.setInt(1, artworkId);
			return stmt.executeUpdate() > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public Artwork getArtworkById(int artworkId) throws ArtWorkNotFoundException {
		String query = "SELECT * FROM Artwork WHERE artworkId = ?";
		try (PreparedStatement stmt = conn.prepareStatement(query)) {
			stmt.setInt(1, artworkId);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				return new Artwork(rs.getInt("ArtworkID"), rs.getString("Title"), rs.getString("Description"),
						rs.getDate("CreationDate"), rs.getString("Medium"), rs.getString("ImageURL"),
						rs.getInt("ArtistID"));
			} else {
				throw new ArtWorkNotFoundException("Artwork with ID " + artworkId + " not found.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ArtWorkNotFoundException("Database error while retrieving artwork.");
		}
	}

	@Override
	public List<Artwork> searchArtworks(String keyword) {
		String query = "SELECT * FROM Artwork WHERE Title LIKE ? OR Description LIKE ?";
		List<Artwork> artworks = new ArrayList<>();
		try (PreparedStatement stmt = conn.prepareStatement(query)) {
			String searchKeyword = "%" + keyword + "%";
			stmt.setString(1, searchKeyword);
			stmt.setString(2, searchKeyword);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				artworks.add(new Artwork(rs.getInt("ArtworkID"), rs.getString("Title"), rs.getString("Description"),
						rs.getDate("CreationDate"), rs.getString("Medium"), rs.getString("ImageURL"),
						rs.getInt("ArtistID")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return artworks;
	}

	@Override
	public boolean addArtworkToFavorite(int userId, int artworkId) throws SQLException {
	    String checkQuery = "SELECT COUNT(*) FROM User_Favorite_Artwork WHERE UserId = ? AND ArtworkId = ?";
	    String insertQuery = "INSERT INTO User_Favorite_Artwork (UserId, ArtworkId) VALUES (?, ?)";

	    try (PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {
	        checkStmt.setInt(1, userId);
	        checkStmt.setInt(2, artworkId);
	        ResultSet rs = checkStmt.executeQuery();
	        if (rs.next() && rs.getInt(1) > 0) {
	            System.out.println("Artwork already added to favorites.");
	            return false;
	        }
	    }

	    try (PreparedStatement stmt = conn.prepareStatement(insertQuery)) {
	        stmt.setInt(1, userId);
	        stmt.setInt(2, artworkId);
	        return stmt.executeUpdate() > 0;
	    }
	}


	@Override
	public boolean removeArtworkFromFavorite(int userId, int artworkId) {
		String query = "DELETE FROM User_Favorite_Artwork WHERE UserId = ? AND ArtworkId = ?";
		try (PreparedStatement stmt = conn.prepareStatement(query)) {
			stmt.setInt(1, userId);
			stmt.setInt(2, artworkId);
			return stmt.executeUpdate() > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	@Override
	public boolean validateUser(int userId, String password) {
	    boolean isValid = false;
	    String query = "SELECT * FROM User WHERE UserID = ? AND Password = ?";
	    
	    try (PreparedStatement stmt = conn.prepareStatement(query)) {
	        stmt.setInt(1, userId);
	        stmt.setString(2, password);
	        try (ResultSet rs = stmt.executeQuery()) {
	            if (rs.next()) {
	                isValid = true;
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    
	    return isValid;
	}

	



	@Override
	public List<Artwork> getUserFavoriteArtworks(int userId) throws UserNotFoundException {
		if (!userExists(userId))
			throw new UserNotFoundException("User ID not found: " + userId);

		List<Artwork> favoriteArtworks = new ArrayList<>();
		String query = "SELECT a.* FROM Artwork a JOIN User_Favorite_Artwork ufa ON a.ArtworkId = ufa.ArtworkId WHERE ufa.UserId = ?";
		try (PreparedStatement stmt = conn.prepareStatement(query)) {
			stmt.setInt(1, userId);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				favoriteArtworks.add(new Artwork(rs.getInt("ArtworkId"), rs.getString("Title"),
						rs.getString("Description"), rs.getDate("CreationDate"), rs.getString("Medium"),
						rs.getString("ImageURL"), rs.getInt("ArtistId")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return favoriteArtworks;
	}

	
	private boolean userExists(int userId) {
		String query = "SELECT UserId FROM User WHERE UserId = ?";
		try (PreparedStatement stmt = conn.prepareStatement(query)) {
			stmt.setInt(1, userId);
			ResultSet rs = stmt.executeQuery();
			return rs.next();
		} catch (SQLException e) {
			return false;
		}
	}


	public boolean addGallery(Gallery gallery) {
        String sql = "INSERT INTO Gallery (Name, Description, Location, curator, OpeningHours) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, gallery.getName());
            stmt.setString(2, gallery.getDescription());
            stmt.setString(3, gallery.getLocation());
            stmt.setInt(4, gallery.getCuratorID());
            stmt.setString(5, gallery.getOpeningHours());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateGallery(Gallery gallery) {
        String sql = "UPDATE Gallery SET Name=?, Description=?, Location=?, curator=?, OpeningHours=? WHERE GalleryID=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, gallery.getName());
            stmt.setString(2, gallery.getDescription());
            stmt.setString(3, gallery.getLocation());
            stmt.setInt(4, gallery.getCuratorID());
            stmt.setString(5, gallery.getOpeningHours());
            stmt.setInt(6, gallery.getGalleryID());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteGallery(int galleryID) {
        String sql = "DELETE FROM Gallery WHERE GalleryID=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, galleryID);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public Gallery getGalleryById(int galleryId) throws GalleryNotFoundException {
        String sql = "SELECT * FROM Gallery WHERE GalleryID=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, galleryId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Gallery(
                    rs.getInt("GalleryID"),
                    rs.getString("Name"),
                    rs.getString("Description"),
                    rs.getString("Location"),
                    rs.getInt("Curator"),
                    rs.getString("OpeningHours")
                );
            } else {
                throw new GalleryNotFoundException("Gallery not found.");
            }
        } catch (SQLException e) {
            throw new GalleryNotFoundException("Database error.");
        }
    }

    public List<Gallery> getAllGalleries() {
        List<Gallery> list = new ArrayList<>();
        String sql = "SELECT * FROM Gallery";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Gallery g = new Gallery(
                    rs.getInt("GalleryID"),
                    rs.getString("Name"),
                    rs.getString("Description"),
                    rs.getString("Location"),
                    rs.getInt("Curator"),
                    rs.getString("OpeningHours")
                );
                list.add(g);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
	
}
