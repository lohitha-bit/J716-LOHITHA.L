package com.example.VirtualArtGallery.dao;

import java.sql.SQLException;

import java.util.List;
import com.example.VirtualArtGallery.entity.*;
import com.example.VirtualArtGallery.exception.*;

public interface IVirtualArtGallery {
    boolean addArtwork(Artwork artwork);
    boolean updateArtwork(Artwork artwork);
    boolean removeArtwork(int artworkId);
    Artwork getArtworkById(int artworkId)throws ArtWorkNotFoundException;
    List<Artwork> searchArtworks(String keyword);

    boolean addArtworkToFavorite(int userId, int artworkId)throws UserNotFoundException, ArtWorkNotFoundException, SQLException;
    boolean removeArtworkFromFavorite(int userId, int artworkId);
    List<Artwork> getUserFavoriteArtworks(int userId)throws UserNotFoundException;
    boolean validateUser(int userId,String password);
    
    boolean addGallery(Gallery gallery);
    boolean updateGallery(Gallery gallery);
    boolean deleteGallery(int galleryId);
    Gallery getGalleryById(int galleryId) throws GalleryNotFoundException;
    List<Gallery> getAllGalleries();
}