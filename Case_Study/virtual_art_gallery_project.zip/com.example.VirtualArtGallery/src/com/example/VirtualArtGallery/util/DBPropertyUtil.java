package com.example.VirtualArtGallery.util;

import java.io.FileInputStream;

import java.io.IOException;
import java.util.Properties;

public class DBPropertyUtil {
	public static String[] getPropertyString(String filename) {
		Properties props = new Properties();

		try (FileInputStream fis = new FileInputStream(filename)) {
			props.load(fis);
			String url = props.getProperty("virtualartgallery.url");
			String username = props.getProperty("virtualartgallery.username");
			String password = props.getProperty("virtualartgallery.password");
			System.out.println(url + username + password);

			return new String[] { url, username, password };
		} catch (IOException e) {
			System.err.println("Failed to load DB properties file: " + filename);
			e.printStackTrace();
			return null;
		}


	}
}
