package com.example.VirtualArtGallery.util;

import java.sql.Connection;


import java.sql.DriverManager;

public class DBConnUtil {
	public static Connection conn;

	public static Connection getConn(String filename) {
		if (conn == null) {
			try {
				String[] connStr = DBPropertyUtil.getPropertyString(filename);
				conn = DriverManager.getConnection(connStr[0], connStr[1], connStr[2]);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return conn;
	}
}
