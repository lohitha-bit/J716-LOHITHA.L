package com.example.VirtualArtGallery.test;

import static org.junit.jupiter.api.Assertions.*;


import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.example.VirtualArtGallery.dao.VirtualArtGalleryServiceImpl;
import com.example.VirtualArtGallery.entity.Artwork;
import com.example.VirtualArtGallery.entity.Gallery;
import com.example.VirtualArtGallery.exception.ArtWorkNotFoundException;
import com.example.VirtualArtGallery.exception.GalleryNotFoundException;
import com.example.VirtualArtGallery.exception.UserNotFoundException;

public class VirtualArtGalleryServiceImplTest {

    static VirtualArtGalleryServiceImpl service;

    @BeforeAll
    public static void setup() {
        service = new VirtualArtGalleryServiceImpl();
    }

// 1. Artwork Management

   @Test
    public void testAddArtwork() {
    	Date creationDate = java.sql.Date.valueOf("2025-04-10");

        Artwork art = new Artwork(20, "Test Art1", "Test Description1", creationDate, "Oil", "img.jpg", 1);
        assertTrue(service.addArtwork(art));
    }

    @Test
    public void testUpdateArtwork() throws ArtWorkNotFoundException {
    	Date creationDate = java.sql.Date.valueOf("2025-01-01");
        Artwork art = new Artwork(3, "Updated Title", "Updated Desc", creationDate, "Acrylic", "url.jpg", 1);
        assertTrue(service.updateArtwork(art));
    }

    @Test
    public void testRemoveArtwork() throws ArtWorkNotFoundException {
        assertTrue(service.removeArtwork(4));
    }

    @Test
    public void testGetArtworkById() throws ArtWorkNotFoundException {
        Artwork art = service.getArtworkById(3);
        assertNotNull(art);
        assertEquals(3, art.getArtworkId());
    }

    // 2. Gallery Management

    @Test
    public void testAddGallery() {
        Gallery gallery = new Gallery(10, "Test Gallery", "Test Desc", "Location", 1, "9AM-5PM");
        assertTrue(service.addGallery(gallery));
    }

    @Test
    public void testUpdateGallery() {
        Gallery gallery = new Gallery(10, "Updated Gallery", "New Desc", "Updated Location", 1, "10AM-6PM");
        assertTrue(service.updateGallery(gallery));
    }

    @Test
    public void testDeleteGallery() {
        assertTrue(service.deleteGallery(10));
    }

    @Test
    public void testSearchGalleryById() throws GalleryNotFoundException {
        Gallery gallery = service.getGalleryById(1);
        assertNotNull(gallery);
    }

    // 3. User Authentication

    @Test
    public void testValidateUserSuccess() {
        assertTrue(service.validateUser(2, "pass2")); 
    }

    @Test
    public void testValidateUserFail() {
        assertFalse(service.validateUser(2, "wrongpass"));
    }

    // 4. Favorite Artworks

    @Test
    public void testAddArtworkToFavorites() throws UserNotFoundException, ArtWorkNotFoundException, SQLException {
        assertTrue(service.addArtworkToFavorite(4, 3)); 
    }

    @Test
    public void testRemoveArtworkFromFavorites() throws UserNotFoundException, ArtWorkNotFoundException {
        assertTrue(service.removeArtworkFromFavorite(2, 3));
    }

    @Test
    public void testGetUserFavorites() throws UserNotFoundException {
        List<Artwork> favorites = service.getUserFavoriteArtworks(2);
        assertNotNull(favorites);
    }
}
