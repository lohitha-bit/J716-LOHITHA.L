package com.example.VirtualArtGallery.exception;

public class GalleryNotFoundException extends Exception {
    private static final long serialVersionUID = 1L;

    public GalleryNotFoundException(String message) {
        super(message);
    }
}
