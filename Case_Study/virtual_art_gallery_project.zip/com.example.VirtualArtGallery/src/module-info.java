/**
 * 
 */
/**
 * 
 */
module com.example.VirtualArtGallery {
	requires java.sql;
	requires java.desktop;
	requires org.junit.jupiter.api;
	requires java.base;
}

